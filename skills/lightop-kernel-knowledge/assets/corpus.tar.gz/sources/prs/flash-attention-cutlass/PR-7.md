---
id: pr-flash-attention-cutlass-7
repo: dcutoolkit/deeplearing/flash-attention-cutlass
pr: 7
title: ds_read_b128 for bwd dim128
author: zhanghj2
date: '2025-01-13'
url: http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/7
source_category: upstream-code
architectures:
- dcu
- gfx928
- gfx936
- gfx938
tags:
- attention
- cutlass
- dcu
- flash-attention
- hip
- rocm
techniques:
- implementation
hardware_features: []
kernel_types:
- attention
languages:
- unknown
captured_at: '2026-05-19T07:28:38.621971+00:00'
status: open
merge_sha: 64d2b4ecd08ee112b45d6dccb9992adc7e383824
inclusion_reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.
changed_paths: []
artifact_dir: evidence/pull-bundles/flash-attention-cutlass/mr-7
---
# ds_read_b128 for bwd dim128

- Repository: `dcutoolkit/deeplearing/flash-attention-cutlass`
- MR: [7](http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/7)
- Decision: `include`
- Reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.

## Changed Paths


## Artifact Bundle

`evidence/pull-bundles/flash-attention-cutlass/mr-7`
