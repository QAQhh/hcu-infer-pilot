---
id: pr-flash-attention-cutlass-6
repo: dcutoolkit/deeplearing/flash-attention-cutlass
pr: 6
title: 敏感词dcu_version改为hcu_version
author: Your Name
date: '2024-12-06'
url: http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/6
source_category: upstream-code
architectures:
- dcu
- gfx928
- gfx936
- gfx938
tags:
- attention
- cutlass
- dcu
- flash-attention
- hip
- rocm
techniques:
- implementation
hardware_features: []
kernel_types:
- attention
languages:
- unknown
captured_at: '2026-05-19T07:28:38.621971+00:00'
status: open
merge_sha: 0214137d90ce1ac08235b6b75dbe9f5e0f9b9ad8
inclusion_reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.
changed_paths: []
artifact_dir: evidence/pull-bundles/flash-attention-cutlass/mr-6
---
# 敏感词dcu_version改为hcu_version

- Repository: `dcutoolkit/deeplearing/flash-attention-cutlass`
- MR: [6](http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/6)
- Decision: `include`
- Reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.

## Changed Paths


## Artifact Bundle

`evidence/pull-bundles/flash-attention-cutlass/mr-6`
