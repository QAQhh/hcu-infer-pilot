---
id: pr-flash-attention-cutlass-4
repo: dcutoolkit/deeplearing/flash-attention-cutlass
pr: 4
title: fa2前向更新
author: lishen
date: '2024-09-10'
url: http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/4
source_category: upstream-code
architectures:
- dcu
- gfx928
- gfx936
- gfx938
tags:
- attention
- cutlass
- dcu
- flash-attention
- hip
- rocm
techniques:
- implementation
hardware_features: []
kernel_types:
- attention
languages:
- cpp
captured_at: '2026-05-19T07:28:38.621971+00:00'
status: open
merge_sha: db527812b304d96eb807ad26540b68f47decf5b6
inclusion_reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.
changed_paths:
- .gitmodules
- csrc/flash_attn/flash_api.cpp
- csrc/flash_attn/src/flash_bwd_launch_template.h
- csrc/flash_attn/src/flash_fwd_kernel.h
- csrc/flash_attn/src/flash_fwd_launch_template.h
- csrc/flash_attn/src/kernel_traits.h
artifact_dir: evidence/pull-bundles/flash-attention-cutlass/mr-4
---
# fa2前向更新

- Repository: `dcutoolkit/deeplearing/flash-attention-cutlass`
- MR: [4](http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/4)
- Decision: `include`
- Reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.

## Changed Paths

- `.gitmodules`
- `csrc/flash_attn/flash_api.cpp`
- `csrc/flash_attn/src/flash_bwd_launch_template.h`
- `csrc/flash_attn/src/flash_fwd_kernel.h`
- `csrc/flash_attn/src/flash_fwd_launch_template.h`
- `csrc/flash_attn/src/kernel_traits.h`

## Artifact Bundle

`evidence/pull-bundles/flash-attention-cutlass/mr-4`
