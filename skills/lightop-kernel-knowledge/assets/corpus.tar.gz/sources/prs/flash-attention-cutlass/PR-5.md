---
id: pr-flash-attention-cutlass-5
repo: dcutoolkit/deeplearing/flash-attention-cutlass
pr: 5
title: feat:update dcu_version to hcu_version
author: bianch
date: '2024-12-06'
url: http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/5
source_category: upstream-code
architectures:
- dcu
- gfx928
- gfx936
- gfx938
tags:
- attention
- cutlass
- dcu
- flash-attention
- hip
- norm
- rocm
techniques:
- kernel-fusion
hardware_features: []
kernel_types:
- attention
- norm
languages:
- python
captured_at: '2026-05-19T07:28:38.621971+00:00'
status: open
merge_sha: faadc56913604cd861eea99c2e3628050846c241
inclusion_reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.
changed_paths:
- csrc/fused_dense_lib/get_version.py
- csrc/layer_norm/get_version.py
- csrc/rotary/get_version.py
- csrc/xentropy/get_version.py
- flash_attn/__init__.py
- get_version.py
artifact_dir: evidence/pull-bundles/flash-attention-cutlass/mr-5
---
# feat:update dcu_version to hcu_version

- Repository: `dcutoolkit/deeplearing/flash-attention-cutlass`
- MR: [5](http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/5)
- Decision: `include`
- Reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.

## Changed Paths

- `csrc/fused_dense_lib/get_version.py`
- `csrc/layer_norm/get_version.py`
- `csrc/rotary/get_version.py`
- `csrc/xentropy/get_version.py`
- `flash_attn/__init__.py`
- `get_version.py`

## Artifact Bundle

`evidence/pull-bundles/flash-attention-cutlass/mr-5`
