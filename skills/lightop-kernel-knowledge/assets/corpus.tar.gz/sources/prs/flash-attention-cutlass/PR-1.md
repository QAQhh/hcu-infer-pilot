---
id: pr-flash-attention-cutlass-1
repo: dcutoolkit/deeplearing/flash-attention-cutlass
pr: 1
title: fa2反向dim128基础版
author: lishen
date: '2024-09-10'
url: http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/1
source_category: upstream-code
architectures:
- dcu
- gfx928
- gfx936
- gfx938
tags:
- attention
- cutlass
- dcu
- flash-attention
- hip
- rocm
techniques:
- implementation
hardware_features:
- bf16
- fp16
kernel_types:
- attention
languages:
- cpp
- cuda-cpp
- hip
captured_at: '2026-05-19T07:28:38.621971+00:00'
status: open
merge_sha: d368e8325bd5a368ac956d9ce0dbf523d575d4c6
inclusion_reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.
changed_paths:
- csrc/flash_attn/flash_api.cpp
- csrc/flash_attn/src/alibi.h
- csrc/flash_attn/src/dropout.h
- csrc/flash_attn/src/flash.h
- csrc/flash_attn/src/flash_bwd_hdim128_bf16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim128_bf16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim128_fp16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim128_fp16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim160_bf16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim160_bf16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim160_fp16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim160_fp16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim192_bf16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim192_bf16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim192_fp16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim192_fp16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim224_bf16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim224_bf16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim224_fp16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim224_fp16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim256_bf16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim256_bf16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim256_fp16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim256_fp16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim32_bf16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim32_bf16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim32_fp16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim32_fp16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim64_bf16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim64_bf16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim64_fp16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim64_fp16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim96_bf16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim96_bf16_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim96_fp16_causal_sm80.cu
- csrc/flash_attn/src/flash_bwd_hdim96_fp16_sm80.cu
- csrc/flash_attn/src/flash_bwd_kernel copy.h
- csrc/flash_attn/src/flash_bwd_kernel.h
- csrc/flash_attn/src/flash_bwd_launch_template.h
- csrc/flash_attn/src/flash_fwd_kernel.h
- csrc/flash_attn/src/kernel_traits.h
- csrc/flash_attn/src/mask.h
- csrc/flash_attn/src/utils.h
artifact_dir: evidence/pull-bundles/flash-attention-cutlass/mr-1
---
# fa2反向dim128基础版

- Repository: `dcutoolkit/deeplearing/flash-attention-cutlass`
- MR: [1](http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/1)
- Decision: `include`
- Reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.

## Changed Paths

- `csrc/flash_attn/flash_api.cpp`
- `csrc/flash_attn/src/alibi.h`
- `csrc/flash_attn/src/dropout.h`
- `csrc/flash_attn/src/flash.h`
- `csrc/flash_attn/src/flash_bwd_hdim128_bf16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim128_bf16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim128_fp16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim128_fp16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim160_bf16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim160_bf16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim160_fp16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim160_fp16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim192_bf16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim192_bf16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim192_fp16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim192_fp16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim224_bf16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim224_bf16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim224_fp16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim224_fp16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim256_bf16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim256_bf16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim256_fp16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim256_fp16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim32_bf16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim32_bf16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim32_fp16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim32_fp16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim64_bf16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim64_bf16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim64_fp16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim64_fp16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim96_bf16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim96_bf16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim96_fp16_causal_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_hdim96_fp16_sm80.cu`
- `csrc/flash_attn/src/flash_bwd_kernel copy.h`
- `csrc/flash_attn/src/flash_bwd_kernel.h`
- `csrc/flash_attn/src/flash_bwd_launch_template.h`
- `csrc/flash_attn/src/flash_fwd_kernel.h`
- `csrc/flash_attn/src/kernel_traits.h`
- `csrc/flash_attn/src/mask.h`
- `csrc/flash_attn/src/utils.h`

## Artifact Bundle

`evidence/pull-bundles/flash-attention-cutlass/mr-1`
