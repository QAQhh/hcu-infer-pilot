---
id: pr-flash-attention-cutlass-8
repo: dcutoolkit/deeplearing/flash-attention-cutlass
pr: 8
title: add out in interface
author: zhanghj2
date: '2025-05-29'
url: http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/8
source_category: upstream-code
architectures:
- dcu
- gfx928
- gfx936
- gfx938
tags:
- attention
- cutlass
- dcu
- flash-attention
- hip
- rocm
techniques:
- implementation
hardware_features: []
kernel_types:
- attention
languages:
- cpp
- python
captured_at: '2026-05-19T07:28:38.621971+00:00'
status: open
merge_sha: c3a75b614d67509ff7a053e762b592f78af6b7ef
inclusion_reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.
changed_paths:
- csrc/flash_attn/flash_api.cpp
- flash_attn/flash_attn_interface.py
artifact_dir: evidence/pull-bundles/flash-attention-cutlass/mr-8
---
# add out in interface

- Repository: `dcutoolkit/deeplearing/flash-attention-cutlass`
- MR: [8](http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/8)
- Decision: `include`
- Reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.

## Changed Paths

- `csrc/flash_attn/flash_api.cpp`
- `flash_attn/flash_attn_interface.py`

## Artifact Bundle

`evidence/pull-bundles/flash-attention-cutlass/mr-8`
