---
id: pr-flash-attention-cutlass-9
repo: dcutoolkit/deeplearing/flash-attention-cutlass
pr: 9
title: fix constexpr error
author: zhanghj2
date: '2025-06-03'
url: http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/9
source_category: upstream-code
architectures:
- dcu
- gfx928
- gfx936
- gfx938
tags:
- attention
- cutlass
- dcu
- flash-attention
- hip
- rocm
techniques:
- implementation
hardware_features: []
kernel_types:
- attention
languages:
- cpp
captured_at: '2026-05-19T07:28:38.621971+00:00'
status: open
merge_sha: 69005222eec83bfa3953d748ad64f7f6fc78707f
inclusion_reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.
changed_paths:
- csrc/flash_attn/src/flash_fwd_kernel.h
- csrc/flash_attn/src/flash_fwd_launch_template.h
artifact_dir: evidence/pull-bundles/flash-attention-cutlass/mr-9
---
# fix constexpr error

- Repository: `dcutoolkit/deeplearing/flash-attention-cutlass`
- MR: [9](http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/9)
- Decision: `include`
- Reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.

## Changed Paths

- `csrc/flash_attn/src/flash_fwd_kernel.h`
- `csrc/flash_attn/src/flash_fwd_launch_template.h`

## Artifact Bundle

`evidence/pull-bundles/flash-attention-cutlass/mr-9`
