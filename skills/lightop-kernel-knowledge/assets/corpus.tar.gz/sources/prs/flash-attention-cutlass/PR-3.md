---
id: pr-flash-attention-cutlass-3
repo: dcutoolkit/deeplearing/flash-attention-cutlass
pr: 3
title: fa2反向dim128基础版fwd细节
author: lishen
date: '2024-09-10'
url: http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/3
source_category: upstream-code
architectures:
- dcu
- gfx928
- gfx936
- gfx938
tags:
- attention
- cutlass
- dcu
- flash-attention
- hip
- rocm
techniques:
- implementation
hardware_features: []
kernel_types:
- attention
languages:
- cpp
captured_at: '2026-05-19T07:28:38.621971+00:00'
status: open
merge_sha: 863fc690121423f39a8b5beeff2297b3426cbff1
inclusion_reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.
changed_paths:
- csrc/flash_attn/src/flash_fwd_kernel.h
artifact_dir: evidence/pull-bundles/flash-attention-cutlass/mr-3
---
# fa2反向dim128基础版fwd细节

- Repository: `dcutoolkit/deeplearing/flash-attention-cutlass`
- MR: [3](http://42.228.13.241:10068/dcutoolkit/deeplearing/flash-attention-cutlass/-/merge_requests/3)
- Decision: `include`
- Reason: Use as LightOp/DCU upstream MR evidence; web/API MR state was unavailable, so validate portability against local LightOp before reuse.

## Changed Paths

- `csrc/flash_attn/src/flash_fwd_kernel.h`

## Artifact Bundle

`evidence/pull-bundles/flash-attention-cutlass/mr-3`
